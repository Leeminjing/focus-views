#include "../r5-004/crash.hpp"
#include <dbghelp.h>
#include <wct.h>
#include <tlhelp32.h>
int wmain(int argc,wchar_t** argv){using namespace r305;try{
    r3::Args args(argc,argv);Log log(args.get(L"--log"));const auto pid=std::stoul(args.get(L"--pid")),tid=std::stoul(args.get(L"--tid"));const auto created=std::stoull(args.get(L"--created"));
    Handle process(OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|SYNCHRONIZE,FALSE,pid));check(process.value!=nullptr,"OpenProcess.cleanup_diagnostic");
    if(r5004::creation(process.value)!=created||WaitForSingleObject(process.value,0)!=WAIT_TIMEOUT)throw Error("diagnostic.pinned_process",ERROR_INVALID_OWNER);
    std::vector<DWORD> threads{tid};
    log.emit("diagnostic_started","\"pid\":"+std::to_string(pid)+",\"tid\":"+std::to_string(tid)+",\"created\":"+std::to_string(created));
    Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD,0));
    if(snapshot.value!=INVALID_HANDLE_VALUE){THREADENTRY32 entry{};entry.dwSize=sizeof(entry);if(Thread32First(snapshot.value,&entry))do{if(entry.th32OwnerProcessID==pid&&entry.th32ThreadID!=tid&&threads.size()<8)threads.push_back(entry.th32ThreadID);}while(Thread32Next(snapshot.value,&entry));}
    log.emit("symbols_begin","\"localOnly\":true");
    SymSetOptions(SYMOPT_UNDNAME|SYMOPT_DEFERRED_LOADS|SYMOPT_FAIL_CRITICAL_ERRORS|SYMOPT_NO_PROMPTS);
    const auto local_path=r3::utf8(std::filesystem::path(args.get(L"--log")).parent_path().wstring());const auto symbols=SymInitialize(process.value,local_path.c_str(),TRUE);
    log.emit("symbols","\"result\":"+std::to_string(symbols)+",\"error\":"+std::to_string(symbols?0:GetLastError())+",\"networkSymbols\":false");
    for(const auto thread_id:threads){if(threads.size()>16)throw Error("diagnostic.thread_bound",ERROR_INVALID_DATA);
        Handle thread(OpenThread(THREAD_GET_CONTEXT|THREAD_SUSPEND_RESUME|THREAD_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,thread_id));
        if(!thread.value){log.emit("thread_unavailable","\"tid\":"+std::to_string(thread_id)+",\"error\":"+std::to_string(GetLastError()));continue;}
        if(GetProcessIdOfThread(thread.value)!=pid)throw Error("diagnostic.thread_owner",ERROR_INVALID_OWNER);
        FILETIME c{},e{},k{},u{};check(GetThreadTimes(thread.value,&c,&e,&k,&u),"GetThreadTimes.diagnostic");const auto thread_created=(std::uint64_t(c.dwHighDateTime)<<32)|c.dwLowDateTime;
        const auto suspended=SuspendThread(thread.value);
        if(suspended==DWORD(-1)){log.emit("thread_suspend_failed","\"tid\":"+std::to_string(thread_id)+",\"error\":"+std::to_string(GetLastError()));continue;}
        CONTEXT cpu{};cpu.ContextFlags=CONTEXT_FULL;const auto captured=GetThreadContext(thread.value,&cpu);const auto error=captured?0:GetLastError();
        log.emit("thread_context","\"tid\":"+std::to_string(thread_id)+",\"created\":"+std::to_string(thread_created)+",\"result\":"+std::to_string(captured)+",\"error\":"+std::to_string(error)+",\"rip\":"+std::to_string(cpu.Rip)+",\"rsp\":"+std::to_string(cpu.Rsp)+",\"previousSuspend\":"+std::to_string(suspended));
        if(captured&&symbols){STACKFRAME64 frame{};frame.AddrPC.Offset=cpu.Rip;frame.AddrStack.Offset=cpu.Rsp;frame.AddrFrame.Offset=cpu.Rbp;frame.AddrPC.Mode=frame.AddrStack.Mode=frame.AddrFrame.Mode=AddrModeFlat;
            for(unsigned n=0;n<32;++n){if(!frame.AddrPC.Offset)break;alignas(SYMBOL_INFO) BYTE storage[sizeof(SYMBOL_INFO)+512]{};auto* symbol=reinterpret_cast<SYMBOL_INFO*>(storage);symbol->SizeOfStruct=sizeof(SYMBOL_INFO);symbol->MaxNameLen=511;DWORD64 displacement=0;const auto named=SymFromAddr(process.value,frame.AddrPC.Offset,&displacement,symbol);
                IMAGEHLP_MODULE64 module{};module.SizeOfStruct=sizeof(module);const auto identified=SymGetModuleInfo64(process.value,frame.AddrPC.Offset,&module);
                log.emit("frame","\"tid\":"+std::to_string(thread_id)+",\"index\":"+std::to_string(n)+",\"pc\":"+std::to_string(frame.AddrPC.Offset)+",\"sp\":"+std::to_string(frame.AddrStack.Offset)+",\"module\":"+json(identified?module.ImageName:"")+",\"symbol\":"+json(named?symbol->Name:"")+",\"displacement\":"+std::to_string(displacement)+",\"symbolType\":"+std::to_string(identified?module.SymType:SymNone));
                if(!StackWalk64(IMAGE_FILE_MACHINE_AMD64,process.value,thread.value,&frame,&cpu,nullptr,SymFunctionTableAccess64,SymGetModuleBase64,nullptr))break;
            }
        }
        const auto resumed=ResumeThread(thread.value);log.emit("thread_resumed","\"tid\":"+std::to_string(thread_id)+",\"result\":"+std::to_string(resumed)+",\"error\":"+std::to_string(resumed==DWORD(-1)?GetLastError():0));
    }
    if(symbols)SymCleanup(process.value);
    log.emit("wait_chain_begin","\"boundedByParentProcess\":true");
    const auto session=OpenThreadWaitChainSession(0,nullptr);
    if(session){WAITCHAIN_NODE_INFO nodes[WCT_MAX_NODE_COUNT]{};DWORD count=WCT_MAX_NODE_COUNT;BOOL cycle=FALSE;const auto result=GetThreadWaitChain(session,0,WCTP_GETINFO_ALL_FLAGS,tid,&count,nodes,&cycle);const auto error=result?0:GetLastError();
        log.emit("wait_chain","\"pid\":"+std::to_string(pid)+",\"tid\":"+std::to_string(tid)+",\"result\":"+std::to_string(result)+",\"error\":"+std::to_string(error)+",\"cycle\":"+std::to_string(cycle));
        if(result)for(DWORD i=0;i<count;++i){const auto& n=nodes[i];const bool thread=n.ObjectType==WctThreadType;log.emit("wait_node","\"index\":"+std::to_string(i)+",\"kind\":"+std::to_string(n.ObjectType)+",\"status\":"+std::to_string(n.ObjectStatus)+(thread?",\"pid\":"+std::to_string(n.ThreadObject.ProcessId)+",\"tid\":"+std::to_string(n.ThreadObject.ThreadId):",\"name\":"+json(n.LockObject.ObjectName)));}
        CloseThreadWaitChainSession(session);
    }else log.emit("wait_chain_unavailable","\"error\":"+std::to_string(GetLastError()));

    return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
