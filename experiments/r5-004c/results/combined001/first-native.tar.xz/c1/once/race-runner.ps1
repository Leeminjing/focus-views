param($Config)
$ErrorActionPreference='Stop';$c=Get-Content $Config -Raw|ConvertFrom-Json
$gate=[Threading.EventWaitHandle]::OpenExisting($c.gate)
[IO.File]::WriteAllText($c.ready,'ready')
if(-not $gate.WaitOne(30000)){throw 'Competition gate timed out'};$gate.Dispose()
& $c.entry -OriginRoot $c.origin -OutDir $c.out -Profile $c.profile -ResultsDir $c.result
